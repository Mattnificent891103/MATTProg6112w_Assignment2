/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.wildliferescuesystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author dell'
 */
// ================= Rescuable =================
 
/** Operations every rescue case must support. */
interface Rescuable {
    void startRescue();
    void completeRescue();
    String generateSummary();
}
 
// ================= RescueStatus =================
 
enum RescueStatus {
    REPORTED("Reported"),
    IN_PROGRESS("Rescue in Progress"),
    UNDER_OBSERVATION("Under Observation"),
    COMPLETED("Completed");
 
    private final String label;
 
    RescueStatus(String label) { this.label = label; }
 
    @Override
    public String toString() { return label; }
}
 
// ================= RescuePriority =================
 
enum RescuePriority {
    LOW("Low"), MEDIUM("Medium"), HIGH("High"), CRITICAL("Critical");
 
    private final String label;
 
    RescuePriority(String label) { this.label = label; }
 
    @Override
    public String toString() { return label; }
}
 
// ================= RescueCase =================
 
/** Abstract base class holding the data common to all rescue types. */
abstract class RescueCase implements Rescuable {
 
    private final String caseId;
    private final String animalName;
    private final String species;
    private final String location;
    private final String ranger;
    private final int rescueDays;
    private final double dailyCareCost;
    private RescueStatus status;
 
    protected RescueCase(String caseId, String animalName, String species, String location,
                         String ranger, int rescueDays, double dailyCareCost) {
        requireText(caseId, "Rescue Case ID");
        requireText(species, "Species");
        requireText(location, "Rescue Location");
        requireText(ranger, "Assigned Ranger");
        requirePositive(rescueDays, "Number of Rescue Days");
        requirePositive(dailyCareCost, "Daily Care Cost");
        this.caseId = caseId.trim();
        this.animalName = (animalName == null || animalName.isBlank()) ? "Unnamed" : animalName.trim();
        this.species = species.trim();
        this.location = location.trim();
        this.ranger = ranger.trim();
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.REPORTED;
    }
 
    // ---- validation helpers (shared with subclasses) ----
    protected static void requireText(String value, String field) {
        if (value == null || value.isBlank())
            throw new IllegalArgumentException(field + " must not be blank.");
    }
 
    protected static void requirePositive(double value, String field) {
        if (value <= 0)
            throw new IllegalArgumentException(field + " must be greater than zero.");
    }
 
    // ---- abstract behaviour: each rescue type supplies its own ----
    public abstract String getRescueType();
    protected abstract double calculateAdditionalCost();
    public abstract RescuePriority determinePriority();
    public abstract String getSpecificDetails();
 
    /** Template method: base care cost plus the type-specific costs. */
    public double calculateTotalCost() {
        return rescueDays * dailyCareCost + calculateAdditionalCost();
    }
 
    // ---- Rescuable ----
    @Override
    public void startRescue() {
        if (status == RescueStatus.IN_PROGRESS || status == RescueStatus.COMPLETED)
            throw new IllegalStateException("This rescue cannot be started (current status: " + status + ").");
        status = RescueStatus.IN_PROGRESS;
    }
 
    @Override
    public void completeRescue() {
        if (status == RescueStatus.COMPLETED)
            throw new IllegalStateException("This rescue is already completed.");
        status = RescueStatus.COMPLETED;
    }
 
    @Override
    public String generateSummary() {
        return String.format(
            "--- Rescue Summary ---%n" +
            "%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s",
            "Rescue Case ID", caseId,
            "Rescue Type", getRescueType(),
            "Species", species,
            "Assigned Ranger", ranger,
            "Rescue Priority", determinePriority(),
            "Current Status", status,
            "Total Rescue Cost", formatMoney(calculateTotalCost()));
    }
 
    /** Formats money like the sample output, e.g. R20 500.00 */
    public static String formatMoney(double amount) {
        return "R" + String.format(Locale.US, "%,.2f", amount).replace(',', ' ');
    }
 
    // ---- getters / controlled setter ----
    public String getCaseId() { return caseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getLocation() { return location; }
    public String getRanger() { return ranger; }
    public int getRescueDays() { return rescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public RescueStatus getStatus() { return status; }
 
    /** Manual update: any status may be set (no transition rules). */
    public void setStatus(RescueStatus newStatus) {
        if (newStatus == null) throw new IllegalArgumentException("Status must not be null.");
        this.status = newStatus;
    }
 
    /** Full details of the case (used by Search and Display All). */
    @Override
    public String toString() {
        return String.format(
            "%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s%n%-16s: %s%n" +
            "%-16s: %d%n%-16s: %s%n%s%n%-16s: %s%n%-16s: %s%n%-16s: %s",
            "Rescue Case ID", caseId,
            "Rescue Type", getRescueType(),
            "Animal Name", animalName,
            "Species", species,
            "Location", location,
            "Assigned Ranger", ranger,
            "Rescue Days", rescueDays,
            "Daily Care Cost", formatMoney(dailyCareCost),
            getSpecificDetails(),
            "Priority", determinePriority(),
            "Status", status,
            "Total Cost", formatMoney(calculateTotalCost()));
    }
}
 
// ================= InjuredAnimalRescue =================
 
class InjuredAnimalRescue extends RescueCase {
 
    public static final double SURGERY_FEE = 5000.0;
    public static final double HIGH_VET_COST_THRESHOLD = 10000.0;
 
    private final String injuryDescription;
    private final double veterinaryCost;
    private final boolean surgeryRequired;
 
    public InjuredAnimalRescue(String caseId, String animalName, String species, String location,
                               String ranger, int days, double dailyCost,
                               String injuryDescription, double veterinaryCost, boolean surgeryRequired) {
        super(caseId, animalName, species, location, ranger, days, dailyCost);
        requireText(injuryDescription, "Injury Description");
        requirePositive(veterinaryCost, "Veterinary Treatment Cost");
        this.injuryDescription = injuryDescription.trim();
        this.veterinaryCost = veterinaryCost;
        this.surgeryRequired = surgeryRequired;
    }
 
    @Override public String getRescueType() { return "Injured Animal Rescue"; }
 
    @Override
    protected double calculateAdditionalCost() {
        return veterinaryCost + (surgeryRequired ? SURGERY_FEE : 0);
    }
 
    /** Surgery = CRITICAL; expensive treatment = HIGH; otherwise MEDIUM. */
    @Override
    public RescuePriority determinePriority() {
        if (surgeryRequired) return RescuePriority.CRITICAL;
        if (veterinaryCost >= HIGH_VET_COST_THRESHOLD) return RescuePriority.HIGH;
        return RescuePriority.MEDIUM;
    }
 
    @Override
    public String getSpecificDetails() {
        return String.format("%-16s: %s%n%-16s: %s%n%-16s: %s",
                "Injury", injuryDescription,
                "Vet Cost", formatMoney(veterinaryCost),
                "Surgery Required", surgeryRequired ? "Yes" : "No");
    }
 
    public String getInjuryDescription() { return injuryDescription; }
    public double getVeterinaryCost() { return veterinaryCost; }
    public boolean isSurgeryRequired() { return surgeryRequired; }
}
 
// ================= OrphanedAnimalRescue =================
 
class OrphanedAnimalRescue extends RescueCase {
 
    public static final double FOSTER_CARE_FEE = 2500.0;
 
    private final int ageInMonths;
    private final double feedingCost;
    private final boolean fosterCareRequired;
 
    public OrphanedAnimalRescue(String caseId, String animalName, String species, String location,
                                String ranger, int days, double dailyCost,
                                int ageInMonths, double feedingCost, boolean fosterCareRequired) {
        super(caseId, animalName, species, location, ranger, days, dailyCost);
        requirePositive(ageInMonths, "Estimated Age (Months)");
        requirePositive(feedingCost, "Feeding Cost");
        this.ageInMonths = ageInMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }
 
    @Override public String getRescueType() { return "Orphaned Animal Rescue"; }
 
    @Override
    protected double calculateAdditionalCost() {
        return feedingCost + (fosterCareRequired ? FOSTER_CARE_FEE : 0);
    }
 
    /** Younger animals are more vulnerable: <=3 months HIGH, <=12 MEDIUM, older LOW. */
    @Override
    public RescuePriority determinePriority() {
        if (ageInMonths <= 3) return RescuePriority.HIGH;
        if (ageInMonths <= 12) return RescuePriority.MEDIUM;
        return RescuePriority.LOW;
    }
 
    @Override
    public String getSpecificDetails() {
        return String.format("%-16s: %d%n%-16s: %s%n%-16s: %s",
                "Age (Months)", ageInMonths,
                "Feeding Cost", formatMoney(feedingCost),
                "Foster Care", fosterCareRequired ? "Yes" : "No");
    }
 
    public int getAgeInMonths() { return ageInMonths; }
    public double getFeedingCost() { return feedingCost; }
    public boolean isFosterCareRequired() { return fosterCareRequired; }
}
 
// ================= EndangeredSpeciesRescue =================
 
class EndangeredSpeciesRescue extends RescueCase {
 
    public static final double SPECIALIST_TEAM_FEE = 8000.0;
 
    private final String classification;
    private final double securityCost;
    private final boolean specialistTeamRequired;
 
    public EndangeredSpeciesRescue(String caseId, String animalName, String species, String location,
                                   String ranger, int days, double dailyCost,
                                   String classification, double securityCost, boolean specialistTeamRequired) {
        super(caseId, animalName, species, location, ranger, days, dailyCost);
        requireText(classification, "Conservation Classification");
        requirePositive(securityCost, "Security Cost");
        this.classification = classification.trim();
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }
 
    @Override public String getRescueType() { return "Endangered Species Rescue"; }
 
    @Override
    protected double calculateAdditionalCost() {
        return securityCost + (specialistTeamRequired ? SPECIALIST_TEAM_FEE : 0);
    }
 
    /** Critically Endangered or specialist team = CRITICAL; all other endangered species = HIGH. */
    @Override
    public RescuePriority determinePriority() {
        if (specialistTeamRequired || classification.equalsIgnoreCase("Critically Endangered"))
            return RescuePriority.CRITICAL;
        return RescuePriority.HIGH;
    }
 
    @Override
    public String getSpecificDetails() {
        return String.format("%-16s: %s%n%-16s: %s%n%-16s: %s",
                "Classification", classification,
                "Security Cost", formatMoney(securityCost),
                "Specialist Team", specialistTeamRequired ? "Yes" : "No");
    }
 
    public String getClassification() { return classification; }
    public double getSecurityCost() { return securityCost; }
    public boolean isSpecialistTeamRequired() { return specialistTeamRequired; }
}
 
// ================= RescueManager =================
 
/** Manages the collection of rescue cases (stored in an ArrayList). */
class RescueManager {
 
    private final ArrayList<RescueCase> cases = new ArrayList<>();
 
    /** @throws IllegalArgumentException if the case is null or its ID already exists */
    public void addCase(RescueCase rescueCase) {
        if (rescueCase == null) throw new IllegalArgumentException("Rescue case must not be null.");
        if (idExists(rescueCase.getCaseId()))
            throw new IllegalArgumentException("Rescue Case ID '" + rescueCase.getCaseId() + "' already exists.");
        cases.add(rescueCase);
    }
 
    public boolean idExists(String id) {
        return findById(id) != null;
    }
 
    /** @return the matching case (ID is case-insensitive) or null if not found */
    public RescueCase findById(String id) {
        if (id == null) return null;
        for (RescueCase c : cases) {
            if (c.getCaseId().equalsIgnoreCase(id.trim())) return c;
        }
        return null;
    }
 
    public boolean updateStatus(String id, RescueStatus newStatus) {
        RescueCase c = findById(id);
        if (c == null) return false;
        c.setStatus(newStatus);
        return true;
    }
 
    public List<RescueCase> getAllCases() {
        return Collections.unmodifiableList(cases);
    }
 
    public int getCaseCount() { return cases.size(); }
 
    public double getTotalEstimatedCost() {
        double total = 0;
        for (RescueCase c : cases) total += c.calculateTotalCost(); // polymorphic call
        return total;
    }
 
    /** Builds the report in the layout of the assignment's example. */
    public String generateReport() {
        String nl = System.lineSeparator();
        String thick = "=".repeat(49);
        String thin = "-".repeat(49);
        StringBuilder sb = new StringBuilder();
        sb.append(thick).append(nl);
        sb.append("WILDLIFE RESCUE REPORT").append(nl);
        sb.append(thick).append(nl);
 
        if (cases.isEmpty()) sb.append(nl).append("No rescue cases recorded.").append(nl);
 
        for (RescueCase c : cases) {
            sb.append(nl);
            sb.append(String.format("%-14s: %s%n", "Case ID", c.getCaseId()));
            sb.append(String.format("%-14s: %s%n", "Type", c.getRescueType()));
            sb.append(String.format("%-14s: %s%n", "Species", c.getSpecies()));
            sb.append(String.format("%-14s: %s%n", "Location", c.getLocation()));
            sb.append(String.format("%-14s: %s%n", "Ranger", c.getRanger()));
            sb.append(String.format("%-14s: %s%n", "Priority", c.determinePriority()));
            sb.append(String.format("%-14s: %s%n", "Status", c.getStatus()));
            sb.append(String.format("%-14s: %s%n", "Total Cost", RescueCase.formatMoney(c.calculateTotalCost())));
            sb.append(nl).append(thin).append(nl);
        }
 
        sb.append(thick).append(nl).append(nl);
        sb.append(String.format("%-19s: %d%n", "Total Rescue Cases", getCaseCount()));
        sb.append(String.format("%-19s: %s", "Total Rescue Cost", RescueCase.formatMoney(getTotalEstimatedCost())));
        return sb.toString();
    }
}
 
// ================= Main =================
 
public class Wildliferescuesystem  {
 
    private static final Scanner in = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();
 
    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            printMenu();
            switch (readInt("Select an option: ", 1, 6)) {
                case 1: createCase(); break;
                case 2: searchCase(); break;
                case 3: updateStatus(); break;
                case 4: displayAll(); break;
                case 5: System.out.println(); System.out.println(manager.generateReport()); break;
                default: running = false; System.out.println("Goodbye.");
            }
        }
    }
 
    private static void printMenu() {
        System.out.println();
        System.out.println("========================================");
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("========================================");
        System.out.println();
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.println();
    }
 
    private static void createCase() {
        System.out.println("\nRescue type: 1. Injured  2. Orphaned  3. Endangered Species");
        int type = readInt("Select type: ", 1, 3);
 
        String id;
        while (true) {
            id = readText("Rescue Case ID: ");
            if (manager.idExists(id)) System.out.println("Error: that Rescue Case ID already exists.");
            else break;
        }
 
        System.out.print("Animal Name (optional): ");
        String name = in.nextLine();
        String species = readText("Species: ");
        String location = readText("Rescue Location: ");
        String ranger = readText("Assigned Ranger: ");
        int days = readInt("Number of Rescue Days: ", 1, Integer.MAX_VALUE);
        double daily = readPositiveDouble("Daily Care Cost (R): ");
 
        RescueCase rc;
        switch (type) {
            case 1:
                rc = new InjuredAnimalRescue(id, name, species, location, ranger, days, daily,
                        readText("Injury Description: "),
                        readPositiveDouble("Veterinary Treatment Cost (R): "),
                        readYesNo("Surgery required?"));
                break;
            case 2:
                rc = new OrphanedAnimalRescue(id, name, species, location, ranger, days, daily,
                        readInt("Estimated Age (months): ", 1, Integer.MAX_VALUE),
                        readPositiveDouble("Feeding Cost (R): "),
                        readYesNo("Foster care required?"));
                break;
            default:
                rc = new EndangeredSpeciesRescue(id, name, species, location, ranger, days, daily,
                        readText("Conservation Classification: "),
                        readPositiveDouble("Security Cost (R): "),
                        readYesNo("Specialist team required?"));
        }
        manager.addCase(rc);
        System.out.println("Rescue case created successfully.");
    }
 
    private static void searchCase() {
        RescueCase c = manager.findById(readText("Rescue Case ID to search: "));
        if (c == null) {
            System.out.println("No rescue case found with that ID.");
        } else {
            System.out.println();
            System.out.println(c);
        }
    }
 
    /** Start, complete, set any status manually, or generate a summary. */
    private static void updateStatus() {
        RescueCase c = manager.findById(readText("Rescue Case ID: "));
        if (c == null) { System.out.println("No rescue case found with that ID."); return; }
 
        System.out.println("Current status: " + c.getStatus());
        System.out.println("1. Start rescue operation");
        System.out.println("2. Complete rescue operation");
        System.out.println("3. Set status manually");
        System.out.println("4. Generate rescue summary");
        int choice = readInt("Select an option: ", 1, 4);
 
        try {
            switch (choice) {
                case 1:
                    c.startRescue();
                    System.out.println("Rescue started. Status: " + c.getStatus());
                    break;
                case 2:
                    c.completeRescue();
                    System.out.println("Rescue completed. Status: " + c.getStatus());
                    break;
                case 3:
                    RescueStatus[] all = RescueStatus.values();
                    for (int i = 0; i < all.length; i++)
                        System.out.println((i + 1) + ". " + all[i]);
                    c.setStatus(all[readInt("New status: ", 1, all.length) - 1]);
                    System.out.println("Status updated to: " + c.getStatus());
                    break;
                default:
                    break;
            }
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println();
        System.out.println(c.generateSummary());
    }
 
    private static void displayAll() {
        if (manager.getCaseCount() == 0) { System.out.println("No rescue cases recorded."); return; }
        for (RescueCase c : manager.getAllCases()) {
            System.out.println();
            System.out.println("----------------------------------------");
            System.out.println(c);
        }
    }
 
    // ---------- input helpers: keep prompting until the input is valid ----------
 
    private static String readText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = in.nextLine().trim();
            if (!s.isEmpty()) return s;
            System.out.println("Error: this field cannot be blank.");
        }
    }
 
    private static int readInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int v = Integer.parseInt(in.nextLine().trim());
                if (v >= min && v <= max) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println(max == Integer.MAX_VALUE
                    ? "Error: enter a whole number of at least " + min + "."
                    : "Error: enter a number between " + min + " and " + max + ".");
        }
    }
 
    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double v = Double.parseDouble(in.nextLine().trim());
                if (v > 0 && !Double.isInfinite(v)) return v;
            } catch (NumberFormatException ignored) { }
            System.out.println("Error: enter a number greater than zero.");
        }
    }
 
    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String s = in.nextLine().trim();
            if (s.equalsIgnoreCase("Y")) return true;
            if (s.equalsIgnoreCase("N")) return false;
            System.out.println("Error: enter Y or N.");
        }
    }
}
 





